package Pack01;

import java.util.Random;

import org.junit.jupiter.api.Test;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import lombok.*;
import net.bytebuddy.implementation.bytecode.Multiplication;

import static org.mockito.BDDMockito.*;



@SpringBootTest
class Msa01ApplicationTests {
  
   void test01() {

      
   }
}



//-------------------------------------------------------------------
//
//@RequiredArgsConstructor// 인수전달이 한개있는 생성자는 무조건 하나있다.
//@ToString
//@Getter
//class User{
//	
//	final String alis;//파이널은 꼭 초기화 시키기
//	
//	User(){
//		//this(null);
//		alis="익명";
//	}
//
//}
//
//
//
//
//@SpringBootTest
//class Msa01ApplicationTests{ 
//	@Test
//	void test01() {
//		User user1=new User("호랑이");
//		User user2=new User();// @RequiredArgsConstructor는 디폹트 생성자가 없다. ㅏ따라서 이거 ㄴ따로 만들어줌
//		System.out.println(user1.toString());
//		System.out.println(user1.getAlis());//@Getter하면 getAlias()볼 수 있다.
//	}
//}
//-------------------------------------------
//어노테이션이 한개이상있는것을 어노테이션을 데코레이트한다고 얘기한다. 양파 껍질까듯
//@Setter 
//@Getter 
//@RequiredArgsConstructor// 파이널에 대해서 생성자를 만들어준다,///@ToString
//@EqualsAndHashCode //이 다섯가지가 @ Data이다.
//@RequiredArgsConstructor

//@RequiredArgsConstructor //파이널 변수로 선언된것에 대해서  생성자를 만들어준다.
//class Tiger{
//	
//	final String name;
//	final int age;
//	
//	Tiger(){ //인수가 있던 없던간에 다 초기화 시켜줌
//		this("",0);
//	}
//
//}
//
//@SpringBootTest
//class Msa01ApplicationTests{ 
//	@Test
//	void test01() {
//		Tiger t1= new Tiger();		
//		Tiger t2= new Tiger("호랑이",10);		
//	}
//}

//어노테이션 사용하기 전의 모습
//class Tiger{
//	
//	final String name;
//	final int age;
//	
//	Tiger(){
//		this("",0);
//	}
//
//	Tiger(String name,int age){
//		this.name=name;
//		this.age=age;
//		
//	}
//	
//}
//
//@SpringBootTest
//class Msa01ApplicationTests{ 
//	@Test
//	void test01() {
//		
//		
//	}
//}



//------------------------------------------------------------

////어노테이션이 한개이상있는것을 어노테이션을 데코레이트한다고 얘기한다. 양파 껍질까듯
////@Setter 
////@Getter 
////@RequiredArgsConstructor// 파이널에 대해서 생성자를 만들어준다,
////@ToString
////@EqualsAndHashCode //이 다섯가지가 @ Data이다.
//
//@Data
//class Tiger{
//	
//	final String nam;
//	final int age;
//
//	
//}
//
//@SpringBootTest
//class Msa01ApplicationTests{ 
//	@Test
//	void test01() {
//		Tiger t2= new Tiger("호랑이",10);//llArgsConstructordl argument 다 만든다.
//		System.out.println(t2.toString());
//		
//	}
//}


//---------------------------------------------------------------------------


//어노테이션이 한개이상있는것을 어노테이션을 데코레이트한다고 얘기한다. 양파 껍질까듯
//@Setter 
//@Getter 
//@NoArgsConstructor//인수전달이 없는 생성자 어노테이션
//@AllArgsConstructor//모든애들의 생성자를 만들어줌
//@ToString// to string도 롬복이 만들어준다.
//@RequiredArgsConstructor// 파이널에 대해서 생성자를 만들어준다,
//@Data

//여기부터 하기
//// 어노테이션이 한개이상있는것을 어노테이션을 데코레이트한다고 얘기한다. 양파 껍질까듯
//@Setter
//@Getter
//@NoArgsConstructor//인수전달이 없는 생성자 어노테이션
//@AllArgsConstructor
//@ToString// to string도 롬복이 만들어준다.
//
//class Tiger{
//	String name;
//	int age;
//	
////	
////	Tiger(){
////	}
//
////	Tiger(int a){
////		
////	}
//	
//}
//
//@SpringBootTest
//class Msa01ApplicationTests{ 
//	@Test
//	void test01() {
//		Tiger t1= new Tiger();
//		Tiger t2= new Tiger("호랑이",10);//argument 다 만든다.
//		System.out.println(t1.toString());
//		System.out.println(t2.toString());
//		
//	}
//}


//-------------------------------------------------------
//
//@Getter
//@Setter
//class Tiger{
//	int num;
//}
//
//@SpringBootTest
//class Msa01ApplicationTests{ 
//	@Test
//	void test01() {
//		Tiger t=new Tiger();
//		t.setNum(10);
//		System.out.println(t.getNum());
//	}
//}



//------------------------------------------------------

//////고유기능 예제에서 B클래스에 해당
////interface MultiplicationService{
////
////int generateRandomfactor();
////}
////
//
//
//class Multiplication{
//int factorA,factorB;
//int result;
//
//Multiplication(int factorA,int factorB)
//{
//    this.factorA=factorA;
//    this.factorB=factorB;
//    this.result=factorA*factorB;
//    
//}
//
////근데 이거 제네레이터 구지 왜있는거지?
//int getFactorA() {return factorA;}
//int getFactorB() {return factorB;}
//int getFactor() {return result;}
//
//
//@Override // 모든 
//public String toString() {
//      return "Multiplication [factor A =" + factorA+ ", factorB=" + factorB+", result =" + result+ "]";
//   }
//
//}
//
//
////고유기능 예제에서 B클래스에 해당
//interface RandomGenaratorService{
//
//int generateRandomfactor();
//}
//
////P28
//@Service
//class RandomGenaratorServiceImpl implements RandomGenaratorService{
//
//
//@Override
//public int generateRandomfactor(){
//    //랜덤한 숫자를 뱉어준다.
//    return new Random().nextInt(100);        
//}
//}
//
//
//
////고유클래스 c에 해당 
//interface MultiplicationService{
//
//Multiplication createRandomMultiplication();
//}
//
//@Service
//class MultiplicationServiceImpl implements MultiplicationService{
//
////잠시보류
//@Autowired  //인터페이스를 업캐스팅 이걸 제일 많이 쓴다.
//RandomGenaratorService randomGenaratorService;//클래스 이름을 받아도 되고 부모이름을 받아도되고 
//
////RandomGenaratorServiceImpl randomGenaratorService; 얘로 써도 된다.
//
//@Override
//public Multiplication createRandomMultiplication() {
//    int factorA=randomGenaratorService.generateRandomfactor();
//    int factorB=randomGenaratorService.generateRandomfactor();
//    return new Multiplication(factorA,factorB);
//}
//}
//
//
//
//
//
//@SpringBootTest
//class Msa01ApplicationTests{ 
//
////
////@MockBean
////RandomGenaratorService  randomGenaratorService;
//
//@Autowired
//MultiplicationServiceImpl MultiplicationServiceImpl;
//
//
//@Test
//void test01() {
//    Multiplication m =MultiplicationServiceImpl.createRandomMultiplication();
//    System.out.println(m.toString());
//}
//
//}
//
