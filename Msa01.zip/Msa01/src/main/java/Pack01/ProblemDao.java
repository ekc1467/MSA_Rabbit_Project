package Pack01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;

public class ProblemDao {
	@Autowired
	   ConnectionProvider conn;
	
//insert 
   public void upload( Personrabbit testnum) {
	      String sql = "insert into person values(null, ?, ?, ?, ?);";
	      try {
	         Connection conn = null;
	         System.out.println("insert1 연결");
	         conn = ConnectionProvider.getConnection();
	         System.out.println("insert2 연결");
	         
	         PreparedStatement pstmt = conn.prepareStatement(sql);
	         System.out.println("insert3 연결");
	         pstmt.setString(1, testnum.name);
	         System.out.println("insert4 연결");
	         pstmt.setInt(2, testnum.factorA);
	         pstmt.setInt(3, testnum.factorB);
	         pstmt.setInt(4, testnum.ans);
	         pstmt.executeUpdate();
	         
	      }catch (Exception e) {
	         // TODO: handle exception
	         System.out.println(e.getMessage());
	      }
	   }
   

   
   public ResultSet loadTwoAnsColum() {
      String sql = "select * from person;";
      try {
         Connection conn = null;
         conn = ConnectionProvider.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql);
         pstmt.executeQuery();
         
         ResultSet rs = pstmt.executeQuery();
         
         return rs;
      }catch (Exception e) {
         // TODO: handle exception
         System.out.println(e.getMessage());
      }
      return null;
   }
   
   public Personrabbit1 PersonalSelect(Integer idx) {
	  // System.out.println("여기 dao의 idx"+idx); //1
	   
	   Connection conn = null;
       Statement stmt = null;
       try {
           Class.forName("com.mysql.cj.jdbc.Driver");
           String url = "jdbc:mysql://localhost:3306/rabbit?useSSL=false&characterEncoding=UTF-8&serverTimezone=UTC";
           conn = DriverManager.getConnection(url, "root", "1234");
           System.out.println("DB CONNECTED!");
           stmt=conn.createStatement();
           
	      String sql = "select * from person where idx ="+idx+";";// idx직접 넣는다.
	      
	      ResultSet rs = stmt.executeQuery(sql);
	      PreparedStatement pstmt = conn.prepareStatement(sql);
	        
//	      pstmt.setInt(1, idx);  
	       pstmt.executeQuery();
	       
	         System.out.println("여기까지는 오니? "); //오네
	         Personrabbit1 person =new Personrabbit1();
	         if(rs.next()) { //rs.next()를 통해 다음행을 내려갈 수 있으면 true를 반환하고, 커서를 한칸 내린다. 다음행이 없으면 false를 반환한다.
					System.out.println(rs.getString("user") + rs.getInt("a")); //getInt(1)은 컬럼의 1번째 값을 Int형으로 가져온다. / getString(2)는 컬럼의 2번째 값을 String형으로 가져온다.
			
					person.setName(rs.getString("user"));
					person.setFactorA(rs.getInt("a"));
					person.setFactorB(rs.getInt("b"));
					person.setAns(rs.getInt("ans"));
	         }
				
	         
	         
				rs.close();
				stmt.close();
				conn.close();

				
	         
	         return person;
	         
	      }catch (Exception e) {
	         // TODO: handle exception
	         System.out.println(e.getMessage());
	      }
       System.out.println("여기까지는 오니?2 "); 
	      return null;
	   }
	   
}

