package Pack01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConnectionProvider {

   public static Connection getConnection()
   {         
      Connection conn = null;
      try {
    	 System.out.println("여기 들어오나?????");
         Class.forName("com.mysql.cj.jdbc.Driver");
         String url = "jdbc:mysql://localhost:3306/rabbit?useSSL=false&characterEncoding=UTF-8&serverTimezone=UTC";
         conn = DriverManager.getConnection(url, "root", "1234");
         System.out.println("여기서 conn을 찍기"+conn);
         
      }catch (Exception e) {
         System.out.println(e.getMessage());
      }
      return conn;
   }

   public static void close(ResultSet rs, Statement stmt, Connection conn)
   {
      try {
         rs.close();
         stmt.close();
         conn.close();
      } catch (Exception e) {
         // TODO Auto-generated catch block
         System.out.println(e.getMessage());
      }
   }
}