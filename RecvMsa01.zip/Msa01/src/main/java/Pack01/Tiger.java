package Pack01;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.amqp.core.ExchangeTypes;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import lombok.Getter;
import lombok.*;




//곱셈객체를 넘겨주겠다.
@RequiredArgsConstructor
@Getter//데이터 보내주는거 하나걸기
@ToString
class Multiplication{
	
	final int factorA;
	final int factorB;
	
	Multiplication(){ //디폴트 생성자
		this(0,0);
	}
}


@AllArgsConstructor//인수가 모두있는 생성자를 만들어주기
@NoArgsConstructor// 디폴트 생성자
@Getter
@Setter
class User{
	String alias;
}



@AllArgsConstructor//인수가 모두있는 생성자를 만들어주기
@NoArgsConstructor// 디폴트 생성자
@Getter
@Setter
class MultiplicationResultAttempt{
	 private User user; //수검자
	 Multiplication multiplication; //문제
	 int resultAttempt;  //답안지
	
	 
}



//랜덤생성서비스 만들기
interface RandomGenService{ 

	int getGenRandom(); 
} 
@Service
class RandomGenServiceImpl implements RandomGenService{ 

	@Override 
	public int getGenRandom() { 
	// TODO Auto-generated method stub 
	return new Random().nextInt(10); 
	
	   } 
} 




//문제 출제서비스 인터페이스 , 인터페이스 안만들어도 됨.
interface MultiplicationService{
	Multiplication createRandomMultiplication();
	boolean checkAttempt(MultiplicationResultAttempt mra); // 인자를 넣어야함 !!!
}

@Service
class MultiplicationServiceImpl implements MultiplicationService {
	
	@Autowired
	RandomGenServiceImpl rs;
	
	//
	public Multiplication createRandomMultiplication() {
		//Random rnd=new Random();
		
		int factorA=rs.getGenRandom();
		int factorB=rs.getGenRandom();
		
		return new Multiplication(factorA,factorB);
	}
	
	
	//답안 채점 서비스 
	public boolean checkAttempt(MultiplicationResultAttempt mra) {
		return mra.getResultAttempt()==
				mra.getMultiplication().getFactorA()*
				mra.getMultiplication().getFactorB();
	}
}




//채점 서비스
@RestController
public class Tiger {
	
	@Autowired
	MultiplicationService ms;
	//MultiplicationServiceImpl ms;
	

	@Autowired
	RabbitTemplate rabbitTemplate;
	
	
	
	@RequestMapping("/t1")
	Multiplication f1() {
		//Multiplication m=ms.createRandomMultiplication();
		//System.out.println(m.getFactorA);
		//System.out.println(m.getFactorB);
		System.out.println("들어옴");
		System.out.println(ms);
		return ms.createRandomMultiplication();
	}
	
	
	@RequestMapping("/t2")
	boolean f2(@RequestBody MultiplicationResultAttempt mra) {// 스프링 커멘드 객체랑 비슷하다.
		

		System.out.println(mra);
		System.out.println(mra.getUser().getAlias());//원래 이거는 전부 다 프라이베잇으로 끌어야한다.
		//System.out.println(mra.user);//원래 이거는 전부 다 프라이베잇으로 끌어야한다.
		System.out.println(mra.multiplication.factorA);
		System.out.println(mra.multiplication.factorB);
		System.out.println(mra.resultAttempt);
		System.out.println("f2 들어옴");
		
		
		//true:tiger 아예 별개의 사이트에다가 쏴버린다. 랭킹서비스 만든다.
		// 이걸 대시보드로 쏴버린다. 서비스 자체를 별개의 서비스로 만든다.
		System.out.println("f3 call");
		
		Personrabbit person=new Personrabbit(mra.getUser().getAlias(),mra.multiplication.factorA,mra.multiplication.factorB,mra.resultAttempt);
		
		System.out.println("여기 객체 저장하는것"+person);
		rabbitTemplate.convertAndSend(
				"exchage01",
				"routingkey02",
				person			);
		
		//return true
		return ms.checkAttempt(mra);	
	}
	

	
	//---------------------------

	
	@GetMapping("/s1/{idx}")// 뒤에 붙어있는 값을 얻는 방법, 슬러시 스코프 사이에다가 받을 변수명을 입력해준다
    public Personrabbit1 f3(@PathVariable String idx) {//appnum을 이 함수 인수인 appNum에다가 넣어준다.
    
	System.out.println("getob로 받은 idx"+idx);            //받았던 값이 appNum에 들어온다.
    Integer p_idx = Integer.parseInt(idx);
    
   ProblemDao dao= new ProblemDao();
   Personrabbit1 person =dao.PersonalSelect(p_idx);

	

	 System.out.println("시작");
	 System.out.println("personrbbit출력"+person);
	 System.out.println(person.getName());
	 System.out.println(person.getFactorA());
	 System.out.println(person.getFactorB());
	 System.out.println(person.getAns());
	 
	 System.out.println("끝");
	 return person;                            
    }
	//------------------------
	
}


	 
//@RestController
//@RequestMapping("/s1")
//class Tiger2{
//	@GetMapping("/{idx}")//데이터를 보내줌
//	Personrabbit f3(@PathVariable String idx) throws SQLException {
//		//Multiplication m=ms.createRandomMultiplication();
//		//System.out.println(m.getFactorA);
//		//System.out.println(m.getFactorB);
//		
//		Integer p_idx = Integer.parseInt(idx);
//		System.out.println("여기 Msa01 p_idx"+p_idx);
//		
//		ProblemDao dao= new ProblemDao();
//		ResultSet rs =dao.PersonalSelect(p_idx);
//		
//		//객체
//		Personrabbit person =new Personrabbit();
//		person.name=rs.getString("user");
//		person.factorA=rs.getInt("a");
//		person.factorB=rs.getInt("b");
//		person.ans=rs.getInt("ans");
//		
//		return person;
//		//rs저장해서 리턴
//		
//		}
//} 
	

//	@Autowired
//	RabbitTemplate rabbitTemplate;
//	
//	public String f3(MultiplicationResultAttempt mra) {// PERSON을 RABBIT에 쏜다
//		System.out.println("f3 call");
//		Personrabbit person=new Personrabbit(mra.user,10,12,120);
//		rabbitTemplate.convertAndSend(
//				"exchage01",
//				"routingkey02",
//				person			);
//		
//		return "redirect:/"; 
//		
//	}    
//	
	//----------------------------------------
	



@ToString
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter 
class Personrabbit{ //MQ에 전달할 객체
	
	 String name;
	 int factorA;
	 int factorB;
	 int ans;
}
// 여기까지가 하나의 마이크로 서비스 
// 곱셈을 받아서 결과를 알려주는 웹사이트




@Setter
@Getter
class Personrabbit1{ //MQ에 전달할 객체
	
	String name;
	int factorA;
	int factorB;
	int ans;
	
	
}

