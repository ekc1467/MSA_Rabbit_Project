package Pack01;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class AnswerDao {
	@Autowired
	   ConnectionProvider conn;

//insert 
   public void upload( Personrabbit testnum) {
	      String sql = "insert into person values(null, ?, ?, ?, ?);";
	      try {
	         Connection conn = null;
	         System.out.println("insert1 연결");
	         conn = ConnectionProvider.getConnection();
	         System.out.println("insert2 연결");
	         
	         PreparedStatement pstmt = conn.prepareStatement(sql);
	         System.out.println("insert3 연결");
	         pstmt.setString(1, testnum.name);
	         System.out.println("insert4 연결");
	         pstmt.setInt(2, testnum.factorA);
	         pstmt.setInt(3, testnum.factorB);
	         pstmt.setInt(4, testnum.ans);
	         pstmt.executeUpdate();
	      }catch (Exception e) {
	         // TODO: handle exception
	         System.out.println(e.getMessage());
	      }
	   }
   

   
   public ResultSet loadTwoAnsColum() {
      String sql = "select * from person;";
      try {
         Connection conn = null;
         conn = ConnectionProvider.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql);
         pstmt.executeQuery();
         ResultSet rs = pstmt.executeQuery();
         
         return rs;
      }catch (Exception e) {
         // TODO: handle exception
         System.out.println(e.getMessage());
      }
      return null;
   }
   

}

