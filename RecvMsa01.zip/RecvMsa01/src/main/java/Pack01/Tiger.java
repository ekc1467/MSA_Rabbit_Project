//recev 
package Pack01;

import org.springframework.amqp.rabbit.annotation.Exchange;

import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.ui.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.amqp.core.ExchangeTypes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@ToString
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter 
class Personrabbit{ //MQ에 전달할 객체
	
	 String name;
	 int factorA;
	 int factorB;
	 int ans;
}


@Controller
public class Tiger {
	@RequestMapping("/")// 루트경로
	public String f0() {
		System.out.println("f0 call");// 메인하면 들어왔다를 알려줌
		
		return "index" ;// 타이거 뷰로 간다.
	}
	
	@RequestMapping("/t1")
	public String f1() {
		System.out.println("f1 call");
		
		return "TigerView" ;// 타이거 뷰로 간다.
		//return "redirect:/"; // 루트경로로 가라
	}
	//테이블 불러오기
	@RequestMapping("/t2")
	public String f2() {
		System.out.println("f1 call");
		return "TigerView" ;// 타이거 뷰로 간다.
		//return "redirect:/"; // 루트경로로 가라	
	}
	//요청하기		
}

//rabbitmq는 컨트롤러로 받으면 안되고 컴포넌트로 받아야한다.
@Component
class RecvModule{		
	@RabbitListener( //일반적으로 응답받을때 사용되는것
	   bindings=@QueueBinding(
			   exchange=@Exchange(name="exchage01", type=ExchangeTypes.TOPIC),
			   value=@Queue(name="queue02"),// 받는거, 받는놈은 받읐을때의 이름을 설정하는것(받는놈id)
			   key="routingkey02" // 주는거, 주는놈의 키값 주는놈이routingkey01이다.
		 )			
	   )	
	
	public void recever(Personrabbit msg) {
		System.out.println("여기가 send로 부터 받아오는곳"+msg.name);
		//PersonMsg.setMsg1(msg);
		AnswerDao a = new AnswerDao();
		a.upload(msg);//정답저장insert 하는 부분, msa01에서 받은 msg==Personrabbit 객체를 insert한다. 
		// DB에 정답을 저장하는 부분.
	}
}

class PersonMsg{
	static Personrabbit msg1;

	public static Personrabbit getMsg1() {
		return msg1;
	}

	public static void setMsg1(Personrabbit msg1) {
		PersonMsg.msg1 = msg1;
	}
	
}










