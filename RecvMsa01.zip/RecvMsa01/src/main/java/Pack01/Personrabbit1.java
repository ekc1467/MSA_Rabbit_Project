package Pack01;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)//json형식으로 받아온걸 객체화 시킴 
@Setter
@Getter 
public class Personrabbit1{// MSA01에서-> MQ-> 거쳐서 넘어온 객체를 받기위해 넘어온 객체와 똑같은 클래스를 선언한다.
	
	public String name;
	public int factorA;
	public int factorB;
	public int ans;
}